Press P to start the game.

Press A and D to move.
Click to shoot.
Press S to use ability. 
(Stomp on a platform and jump higher)

The menu is not work yet